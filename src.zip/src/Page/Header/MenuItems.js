export const MenuItems = [
  {
    title: 'Tech-Radar',
    path: '/register',
    cName: 'dropdown-link'
  },
  {
    title: 'Consulting',
    path: '/register',
    cName: 'dropdown-link'
  },
  {
    title: 'Design',
    path: '/register',
    cName: 'dropdown-link'
  },
  {
    title: 'Development',
    path: '/register',
    cName: 'dropdown-link'
  }
];

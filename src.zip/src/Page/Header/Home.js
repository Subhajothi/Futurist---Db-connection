import React from 'react';
import 'src/App/App.css';

export default function Home() {
  return (
    <>
      <h1 className='home'>EPIC</h1>
    </>
  );
}
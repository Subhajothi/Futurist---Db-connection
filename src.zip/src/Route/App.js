import React, { Suspense } from 'react'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import loadable from '@loadable/component'
import Navbar from 'src/Page/Header/Navbar';
import 'src/App/App.css';
import Home from 'src/Page/Header/Home';
const Carousel = loadable(() => import('src/Page/Carousel/Carouse.js'))
const Login = loadable(() => import('src/Page/Login/index.jsx'))
const Header = loadable(() => import('src/Page/Header/Navbar.js'))
function App() {
  return (
    <Router>
      <Navbar />
      <Switch>
        <Route path='/' exact component={Home} />
        <Route path='/services' component={Services} />
        <Route path='/products' component={Products} />
        <Route path='/contact-us' component={ContactUs} />
        <Route path='/sign-up' component={SignUp} />
        <Route path='/marketing' component={Marketing} />
        <Route path='/consulting' component={Consulting} />
      </Switch>
    </Router>
  );
}

export default App;